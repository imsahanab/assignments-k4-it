// built-in File System module is Used to read, write, and manage files
const fs = require("fs");

// Import the Logger class from logger.js #reference:where we exported down in logge.js file
const Logger = require("./logger");

// object of Logger
const logger = new Logger();

// Listen for the "log" event
logger.on("log", (level, message) => {

  // Create a formatted log message 1st info or debug or error then the message related to that.
  // Example we used here: [INFO] Server Started
  const logMessage = `[${level}] ${message}`;

 
  fs.appendFileSync("logs.txt", logMessage); 
  // for my reference:
  //fs -the File System module provided by Node.js. It is used to create, read, update, and delete files.
// append -adds content to the end of smething.
// Sync - its synchronous. Node.js waits for the file operation to finish before moving to the next line of code.
// logs.txt → The name of the file where the data will be stored.if the file doesn't exist thwn Node.js creates it automatically.
// logMessage → The content (text) that will be written into the file.

  // Print the log msg on the console
  console.log(logMessage);
});

// Triggering INFO log
logger.info("Server Started");

// Triggering a DEBUG log
logger.debug("Fetching Users");

// Triggerinf an ERROR log
logger.error("Database Failed");