//import EventEmitter class from node
const EventEmitter = require("events");

// Create Logger class that inherits EventEmitter features like emit 
class Logger extends EventEmitter {
  // method that created for INFO logs
  info(message)
  {
    // if we trigger a "log" event then Pass "INFO" and the actual message as data. 
    this.emit("log", "INFO", message);
  }

  // Method for DEBUG
  debug(message)
  {
    //if we trigger a "log" eventPass "DEBUG" and the actual message as data
    this.emit("log", "DEBUG", message);
  }

  // Method for ERROR logs
  error(message)
  {
    // Pass "ERROR" and the actual message as data
    this.emit("log", "ERROR", message);
  }
}