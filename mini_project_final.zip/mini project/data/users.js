const users = [
  {
    email: "sahana@gmail.com",
    password: "123"
  },
  {
    email: "admin@gmail.com",
    password: "456"
  }
];

module.exports = users;