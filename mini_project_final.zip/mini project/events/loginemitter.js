const EventEmitter = require("events");

const loginEmitter = new EventEmitter();

loginEmitter.on("login", (user) => {

    console.log(
        `${user.email} logged in successfully`
    );

});

module.exports = loginEmitter;