const express = require("express");

const loginEmitter =
require("./events/loginemitter");

const app = express();

app.use(express.json());

app.use(express.static("public"));

app.post("/login", (req, res) => {

    const { email, password } =
    req.body;

    if (
        email === "sahana@gmail.com" &&
        password === "123"
    ) {

        loginEmitter.emit(
            "login",
            { email }
        );

        return res.json({
            message:
            "Login Successful"
        });
    }

    res.json({
        message:
        "Invalid Credentials"
    });

});

app.listen(3000, () => {
    console.log("Server Running");
});